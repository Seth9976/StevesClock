// 函数: $LN17
// 地址: 0x4089f8
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (*(arg1 + 0x10) != 0)
    __unlock(8)
