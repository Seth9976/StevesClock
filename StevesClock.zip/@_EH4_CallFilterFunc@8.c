// 函数: @_EH4_CallFilterFunc@8
// 地址: 0x40f342
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t ecx
return ecx()
