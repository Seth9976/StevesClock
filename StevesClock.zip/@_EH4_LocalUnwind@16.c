// 函数: @_EH4_LocalUnwind@16
// 地址: 0x40f38b
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return __local_unwind4(arg4, arg1, arg2)
