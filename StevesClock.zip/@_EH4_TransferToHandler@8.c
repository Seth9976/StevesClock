// 函数: @_EH4_TransferToHandler@8
// 地址: 0x40f359
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

__NLG_Notify(arg1, arg2, 1)
jump(arg1)
