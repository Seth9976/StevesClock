// 函数: RtlUnwind
// 地址: 0x4159dc
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return RtlUnwind(TargetFrame, TargetIp, ExceptionRecord, ReturnValue) __tailcall
