// 函数: __FF_MSGBANNER
// 地址: 0x40ed71
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

uint32_t result

if (__set_error_mode(3) == 1)
    sub_40ebc2(0xfc)
    result = sub_40ebc2(0xff)
else
    result = __set_error_mode(3)
    
    if (result == 0 && data_41a290 == 1)
        sub_40ebc2(0xfc)
        result = sub_40ebc2(0xff)

return result
