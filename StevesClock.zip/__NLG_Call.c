// 函数: __NLG_Call
// 地址: 0x413b54
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t eax
return eax()
