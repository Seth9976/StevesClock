// 函数: __NLG_Notify
// 地址: 0x413b35
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

data_41b298 = arg3
data_41b294 = arg1
data_41b29c = arg2
int32_t var_c = arg2
int32_t var_10 = arg3
return arg1
