// 函数: ___acrt_initialize_signal_handlers
// 地址: 0x40e69f
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

data_42e254 = arg1
data_42e258 = arg1
data_42e25c = arg1
data_42e260 = arg1
return arg1
