// 函数: ___acrt_locale_free_monetary
// 地址: 0x410879
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (arg1 == 0)
    return 

int32_t eax_1 = *(arg1 + 0xc)

if (eax_1 != data_41af44)
    __free_base(eax_1)

int32_t eax_2 = *(arg1 + 0x10)

if (eax_2 != data_41af48)
    __free_base(eax_2)

int32_t eax_3 = *(arg1 + 0x14)

if (eax_3 != data_41af4c)
    __free_base(eax_3)

int32_t eax_4 = *(arg1 + 0x18)

if (eax_4 != data_41af50)
    __free_base(eax_4)

int32_t eax_5 = *(arg1 + 0x1c)

if (eax_5 != data_41af54)
    __free_base(eax_5)

int32_t eax_6 = *(arg1 + 0x20)

if (eax_6 != data_41af58)
    __free_base(eax_6)

int32_t eax_7 = *(arg1 + 0x24)

if (eax_7 != data_41af5c)
    __free_base(eax_7)

int32_t eax_8 = *(arg1 + 0x38)

if (eax_8 != data_41af70)
    __free_base(eax_8)

int32_t eax_9 = *(arg1 + 0x3c)

if (eax_9 != data_41af74)
    __free_base(eax_9)

int32_t eax_10 = *(arg1 + 0x40)

if (eax_10 != data_41af78)
    __free_base(eax_10)

int32_t eax_11 = *(arg1 + 0x44)

if (eax_11 != data_41af7c)
    __free_base(eax_11)

int32_t eax = *(arg1 + 0x48)

if (eax != data_41af80)
    __free_base(eax)

int32_t esi_1 = *(arg1 + 0x4c)

if (esi_1 != data_41af84)
    __free_base(esi_1)
