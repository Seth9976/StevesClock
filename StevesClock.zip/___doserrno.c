// 函数: ___doserrno
// 地址: 0x409069
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

uint32_t* eax_2 = sub_40add8()

if (eax_2 != 0)
    return &eax_2[3]

return 0x41a46c
