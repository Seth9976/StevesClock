// 函数: ___initmbctable
// 地址: 0x40a94a
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (data_42eb14 == 0)
    sub_40a7b0(0xfffffffd)
    data_42eb14 = 1

return 0
