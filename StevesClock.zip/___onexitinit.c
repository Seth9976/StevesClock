// 函数: ___onexitinit
// 地址: 0x40e978
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t* eax = __calloc_crt(0x20, 4)
int32_t eax_1 = EncodePointer(eax)
data_42eb10 = eax_1
data_42eb0c = eax_1

if (eax == 0)
    return 0x18

*eax = 0
return 0
