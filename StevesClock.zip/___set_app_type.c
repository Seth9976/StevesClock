// 函数: ___set_app_type
// 地址: 0x40e8b3
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

data_42e26c = arg1
return arg1
