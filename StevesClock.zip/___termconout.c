// 函数: ___termconout
// 地址: 0x414e33
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

BOOL hObject = data_41b2a0

if (hObject != 0xffffffff && hObject != 0xfffffffe)
    return CloseHandle(hObject)

return hObject
