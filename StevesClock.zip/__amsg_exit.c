// 函数: __amsg_exit
// 地址: 0x408a57
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

__FF_MSGBANNER()
sub_40ebc2(arg1)
_quick_exit(0xff)
noreturn
