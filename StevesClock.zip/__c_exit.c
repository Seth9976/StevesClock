// 函数: __c_exit
// 地址: 0x408a48
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return sub_4088cd(0, 1, 1)
