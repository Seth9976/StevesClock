// 函数: __callnewh
// 地址: 0x40d9a9
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t eax = DecodePointer(data_42e0f4)

if (eax != 0 && eax(arg1) != 0)
    return 1

return 0
