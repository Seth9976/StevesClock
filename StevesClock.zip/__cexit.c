// 函数: __cexit
// 地址: 0x408a39
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return sub_4088cd(0, 0, 1)
