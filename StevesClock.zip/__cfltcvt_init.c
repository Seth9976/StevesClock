// 函数: __cfltcvt_init
// 地址: 0x4074dc
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

data_41ace8 = __raise_exc
data_41acec = __mbsnextc
data_41acf0 = __mbscat_s
data_41acf4 = __ismbcl2
data_41acf8 = sub_40c433
data_41acfc = __raise_exc
data_41ad00 = __cfltcvt_l
data_41ad04 = sub_40c44f
data_41ad08 = sub_40c3b1
data_41ad0c = sub_40c33d
return __raise_exc
