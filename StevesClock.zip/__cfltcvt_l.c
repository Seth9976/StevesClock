// 函数: __cfltcvt_l
// 地址: 0x40cd5f
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (arg4 == 0x65 || arg4 == 0x45)
    return sub_40c651(arg1, arg2, arg3, arg5, arg6.b, arg7)

if (arg4 == 0x66)
    return sub_40cbb1(arg1, arg2, arg3, arg5, arg7)

if (arg4 != 0x61 && arg4 != 0x41)
    return sub_40cc72(arg1, arg2, arg3, arg5, arg6.b, arg7)

return sub_40c738(arg1, arg2, arg3, arg5, arg6, arg7)
