// 函数: __endthreadex
// 地址: 0x4087b5
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

sub_40878a(arg1)
ExitProcess(arg1)
noreturn
