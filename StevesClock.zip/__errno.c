// 函数: __errno
// 地址: 0x409056
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

uint32_t* eax_2 = sub_40add8()

if (eax_2 != 0)
    return &eax_2[2]

return 0x41a468
