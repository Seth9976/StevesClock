// 函数: __fpmath
// 地址: 0x40753c
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t result = __cfltcvt_init()

if (arg1 != 0)
    result = sub_40ce2d()

__fnclex()
return result
