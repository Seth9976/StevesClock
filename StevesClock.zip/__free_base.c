// 函数: __free_base
// 地址: 0x4067fe
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (arg1 != 0 && HeapFree(data_42dd98, HEAP_NONE, arg1) == 0)
    BOOL* esi_1 = __errno()
    *esi_1 = sub_409014(GetLastError())
