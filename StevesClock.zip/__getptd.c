// 函数: __getptd
// 地址: 0x40ae51
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

uint32_t* result = sub_40add8()

if (result != 0)
    return result

__amsg_exit(0x10)
noreturn
