// 函数: __heap_init
// 地址: 0x409b8a
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

HANDLE eax = HeapCreate(HEAP_NONE, 0x1000, 0)
int32_t result
result.b = eax != 0
data_42dd98 = eax
return result
