// 函数: __initp_eh_hooks
// 地址: 0x40e68e
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t result = EncodePointer(terminate)
data_42e250 = result
return result
