// 函数: __initp_misc_invarg
// 地址: 0x408e7a
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

data_42dcd8 = arg1
return arg1
