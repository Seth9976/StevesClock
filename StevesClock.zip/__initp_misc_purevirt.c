// 函数: __initp_misc_purevirt
// 地址: 0x40d99a
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

data_42e0f4 = arg1
return arg1
