// 函数: __invalid_parameter
// 地址: 0x408fd7
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t eax = DecodePointer(data_42dcd8)

if (eax != 0)
    jump(eax)

int32_t var_8_1 = arg5
int32_t var_c = arg4
int32_t var_10 = arg3
int32_t var_14 = arg2
int32_t var_18 = arg1
sub_408fb2()
noreturn
