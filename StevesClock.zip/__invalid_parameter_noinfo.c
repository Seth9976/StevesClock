// 函数: __invalid_parameter_noinfo
// 地址: 0x409004
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return __invalid_parameter(0, 0, 0, 0, 0)
