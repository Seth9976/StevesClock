// 函数: __ismbblead
// 地址: 0x413baa
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return sub_413b57(nullptr, arg1, 0, 4)
