// 函数: __ismbcl2
// 地址: 0x40c4ca
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return sub_40c33d(arg1, nullptr)
