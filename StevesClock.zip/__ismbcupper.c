// 函数: __ismbcupper
// 地址: 0x408116
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return sub_40806b(arg1, nullptr)
