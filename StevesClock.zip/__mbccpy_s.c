// 函数: __mbccpy_s
// 地址: 0x410e2b
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t var_8 = 0
return sub_410cd6(arg1, arg2, arg3, arg4)
