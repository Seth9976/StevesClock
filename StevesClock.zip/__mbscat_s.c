// 函数: __mbscat_s
// 地址: 0x40c491
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t var_8 = 0
int32_t eax
int32_t ecx
int32_t edx
return sub_40c44f(eax, edx, ecx, arg1, arg2, arg3)
