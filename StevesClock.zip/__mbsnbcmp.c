// 函数: __mbsnbcmp
// 地址: 0x4126c3
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return sub_4125ad(arg1, arg2, arg3, nullptr)
