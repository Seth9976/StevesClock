// 函数: __mbsnbicoll
// 地址: 0x4139ff
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return sub_4138b3(arg1, arg2, arg3, nullptr)
