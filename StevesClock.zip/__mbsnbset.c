// 函数: __mbsnbset
// 地址: 0x413ef6
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return sub_413e18(arg1, arg2, arg3, nullptr)
