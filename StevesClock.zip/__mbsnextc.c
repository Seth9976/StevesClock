// 函数: __mbsnextc
// 地址: 0x40c4dd
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return sub_40c3b1(arg1, nullptr)
