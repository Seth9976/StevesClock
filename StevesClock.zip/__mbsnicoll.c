// 函数: __mbsnicoll
// 地址: 0x413899
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return sub_413695(arg1, arg2, arg3, nullptr)
