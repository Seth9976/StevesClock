// 函数: ?_msize_base@@YAIQAX@Z
// 地址: 0x412adf
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (arg1 != 0)
    return HeapSize(data_42dd98, HEAP_NONE, arg1)

*__errno() = 0x16
__invalid_parameter_noinfo()
return 0xffffffff
