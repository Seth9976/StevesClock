// 函数: __raise_exc
// 地址: 0x40cde7
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return __cfltcvt_l(arg1, arg2, arg3, arg4, arg5, arg6, nullptr)
