// 函数: __seh_longjmp_unwind4@4
// 地址: 0x40f326
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

*arg1
return __local_unwind4(arg1[0xa], arg1[6], arg1[7])
