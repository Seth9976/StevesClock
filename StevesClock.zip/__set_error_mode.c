// 函数: __set_error_mode
// 地址: 0x412e3e
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (arg1 s>= 0)
    if (arg1 s<= 2)
        int32_t result = data_42dcd4
        data_42dcd4 = arg1
        return result
    
    if (arg1 == 3)
        return data_42dcd4

*__errno() = 0x16
__invalid_parameter_noinfo()
return 0xffffffff
