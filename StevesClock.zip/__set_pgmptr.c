// 函数: __set_pgmptr
// 地址: 0x40e8a4
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

data_42e268 = arg1
return arg1
