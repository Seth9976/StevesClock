// 函数: __snwscanf_l
// 地址: 0x403d72
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

void arg_14
return sub_402547(arg1, arg2, arg3, arg4, &arg_14)
