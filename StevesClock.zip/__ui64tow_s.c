// 函数: __ui64tow_s
// 地址: 0x40c718
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return sub_40c651(arg1, arg2, arg3, arg4, arg5, 0)
