// 函数: __unlock
// 地址: 0x40e31c
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return LeaveCriticalSection(*((arg1 << 3) + &data_41ad10))
