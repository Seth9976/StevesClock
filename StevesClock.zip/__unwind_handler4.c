// 函数: __unwind_handler4
// 地址: 0x40f2e0
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if ((*(arg1 + 4) & 6) == 0)
    return 1

sub_407fad(*(arg2 + 8) ^ arg2)
*(arg2 + 0x18)
__local_unwind4(*(arg2 + 0x14), *(arg2 + 0x10), *(arg2 + 0xc))
*arg3 = arg2
return 3
