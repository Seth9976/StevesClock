// 函数: __wsopen_s
// 地址: 0x413675
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return sub_4135b1(arg2, arg3, arg4, arg5, arg1, 1)
