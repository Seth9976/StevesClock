// 函数: _atexit
// 地址: 0x40e9e5
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t eax = sub_40e9a9(arg1)
int32_t eax_1 = neg.d(eax)
return neg.d(sbb.d(eax_1, eax_1, eax != 0)) - 1
