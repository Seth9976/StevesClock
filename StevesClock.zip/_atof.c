// 函数: _atof
// 地址: 0x40d0fe
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return sub_40d0c6(arg1, nullptr)
