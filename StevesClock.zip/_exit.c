// 函数: _exit
// 地址: 0x408a0d
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

sub_4088cd(status, 0, 0)
