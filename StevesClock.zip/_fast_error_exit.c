// 函数: _fast_error_exit
// 地址: 0x408c54
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (data_42dcd4 == 1)
    __FF_MSGBANNER()

sub_40ebc2(arg1)
__endthreadex(0xff)
noreturn
