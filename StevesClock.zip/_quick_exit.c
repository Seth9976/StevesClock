// 函数: _quick_exit
// 地址: 0x408a23
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

sub_4088cd(exit_code, 1, 0)
