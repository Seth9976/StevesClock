// 函数: _start
// 地址: 0x408dea
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

sub_40f963()
int32_t esi
int32_t edi
return sub_408c7d(esi, edi) __tailcall
