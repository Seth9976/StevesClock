// 函数: _wcsftime
// 地址: 0x407f8e
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return sub_407e02(arg1, arg2, arg3, arg4, nullptr, nullptr)
