// 函数: sub_401090
// 地址: 0x401090
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

uint32_t eax = sub_406984(arg1)
_vwscanf(eax, arg1)
int32_t result
result.b = eax == 0xffffffff
return result
