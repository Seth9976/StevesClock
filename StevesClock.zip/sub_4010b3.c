// 函数: sub_4010b3
// 地址: 0x4010b3
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

void* esi = _strlen(arg1)

if (arg2 s< 1)
    int32_t var_c_1 = 1
    return sub_401000(1, 0x80)

if (arg2 s< esi)
    esi = arg2

int32_t var_c_2 = 1
return sub_406a80(sub_401000(esi, 0x80), arg1, esi)
