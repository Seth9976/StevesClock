// 函数: sub_4010ff
// 地址: 0x4010ff
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

void* eax = _strlen(arg1)
int32_t var_10 = 1
char* eax_1 = sub_401000(eax, 0x80)
void* esi_1 = eax - arg2

if (eax - arg2 s< 0)
    esi_1 = nullptr

return _strcpy(eax_1, esi_1 + arg1)
