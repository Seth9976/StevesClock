// 函数: sub_401133
// 地址: 0x401133
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

void* eax = _strlen(arg1)

if (arg2 s> eax || arg2 s< 1)
    int32_t __saved_edi_1 = 1
    return sub_401000(1, 0x80)

void* edi_1 = arg3

if (edi_1 s< 0 || edi_1 s> eax - arg2 + 1)
    edi_1 = eax - arg2 + 1

int32_t var_10_1 = 1
return sub_406a80(sub_401000(edi_1, 0x80), &arg1[arg2 - 1], edi_1)
