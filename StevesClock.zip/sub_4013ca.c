// 函数: sub_4013ca
// 地址: 0x4013ca
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t var_4 = 1
return __strupr(_strcpy(sub_401000(_strlen(arg1), 0x80), arg1))
