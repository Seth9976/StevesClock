// 函数: sub_4013f5
// 地址: 0x4013f5
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t var_8 = 1
char* result = sub_401000(0x18, 0x80)
sub_407458(result, "% .15G")
return result
