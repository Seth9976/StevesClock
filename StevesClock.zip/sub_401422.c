// 函数: sub_401422
// 地址: 0x401422
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t var_8 = 1
uint8_t* lpBuffer = sub_401000(0x800, 0x80)
GetCurrentDirectoryA(0x400, lpBuffer)
return lpBuffer
