// 函数: sub_401535
// 地址: 0x401535
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t var_8 = 1
char* result = sub_401000(0xb, 0x80)
*result = arg1
result[1] = arg2
result[2] = arg3
result[3] = arg4
result[4] = arg5
result[5] = arg6
result[6] = arg7
result[7] = arg8
result[8] = arg9
result[9] = arg10
result[0xa] = 0
return result
