// 函数: sub_4015f2
// 地址: 0x4015f2
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

for (int32_t i = 0; i s< 0x100; i += 1)
    (&data_423f48)[i] = i.b

data_423f48 = 1
data_424048 = 0
CharLowerA(&data_423f48)
data_423f48 = 0
return &data_423f48
