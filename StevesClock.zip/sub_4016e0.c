// 函数: sub_4016e0
// 地址: 0x4016e0
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t result
result.b = GetFileAttributesA(arg1) != 0xffffffff
return result
