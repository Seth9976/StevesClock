// 函数: sub_401df0
// 地址: 0x401df0
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

char* var_10_1 = &data_41eba8
char const* const var_14_1 = "Close "
void* const result = mciSendStringA(sub_40158a(2), &data_4162eb, 0, nullptr)
data_424060 = result
data_41eba8 = 0
data_41db88 = 0
return result
