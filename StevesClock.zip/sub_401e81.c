// 函数: sub_401e81
// 地址: 0x401e81
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

char* var_10_1 = &data_41eba8
char const* const var_14_1 = "Stop "
void* const result = mciSendStringA(sub_40158a(2), &data_4162eb, 0, nullptr)
data_424068 = result
return result
