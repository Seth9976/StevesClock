// 函数: sub_401eb3
// 地址: 0x401eb3
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

char const* const var_14 = " mode"
char* var_18 = &data_41eba8
char const* const var_1c = "Status "
data_424070 = mciSendStringA(sub_40158a(3), &data_424078, 0xff, nullptr)
void* eax_3 = _strlen(&data_424078)
data_42406c = eax_3
return sub_4010b3(&data_424078, eax_3)
