// 函数: sub_401f08
// 地址: 0x401f08
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t* result = data_41fdc0

if (result != 0)
    result = sub_40172e(result, 2, 1)
    data_41fdc0 = 0

return result
