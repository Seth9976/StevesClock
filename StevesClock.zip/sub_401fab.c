// 函数: sub_401fab
// 地址: 0x401fab
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

Shell_NotifyIconA(NIM_ADD, &data_41fbb0)
BOOL result = ShowWindow(data_41eb90, SW_HIDE)
data_41cb34 = 1
return result
