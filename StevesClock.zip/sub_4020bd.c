// 函数: sub_4020bd
// 地址: 0x4020bd
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

BOOL result

for (int32_t id = 0; id s<= 5; id += 1)
    result = UnregisterHotKey(data_41eb90, id)

return result
