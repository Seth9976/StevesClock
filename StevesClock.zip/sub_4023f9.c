// 函数: sub_4023f9
// 地址: 0x4023f9
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return SendMessageA(arg1, 0x143, 0, arg2)
