// 函数: sub_40240f
// 地址: 0x40240f
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return SendMessageA(arg1, 0x146, 0, 0)
