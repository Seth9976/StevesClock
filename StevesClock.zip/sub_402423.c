// 函数: sub_402423
// 地址: 0x402423
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return SendMessageA(arg1, 0x147, 0, 0)
