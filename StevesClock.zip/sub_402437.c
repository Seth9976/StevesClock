// 函数: sub_402437
// 地址: 0x402437
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

LRESULT wParam = SendMessageA(arg1, 0x147, 0, 0)
data_424994 = wParam
SendMessageA(arg1, 0x148, wParam, 0x424998)
int32_t var_c = 1
char* result = sub_401000(_strlen(0x424998), 0x80)
_strcpy(result, 0x424998)
return result
