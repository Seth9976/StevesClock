// 函数: sub_40248a
// 地址: 0x40248a
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return SendMessageA(arg1, 0x14b, 0, 0)
