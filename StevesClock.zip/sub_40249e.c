// 函数: sub_40249e
// 地址: 0x40249e
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return SendMessageA(arg1, 0x14e, arg2, 0)
