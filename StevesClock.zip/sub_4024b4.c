// 函数: sub_4024b4
// 地址: 0x4024b4
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (arg1 != 0 && arg2 != 0 && *arg2 != 0 && arg3 s<= _strlen(arg1))
    char* eax_2 = &arg1[arg3 - 1]
    int32_t eax_3
    
    if (arg4 == 0)
        if (arg3 s<= 0)
            eax_2 = arg1
        
        eax_3 = sub_40166d(eax_2, arg2)
    else
        if (arg3 s<= 0)
            eax_2 = arg1
        
        eax_3 = sub_401628(eax_2, arg2)
    
    int32_t eax_4 = neg.d(eax_3)
    return sbb.d(eax_4, eax_4, eax_3 != 0) & (eax_3 - arg1 + 1)

return nullptr
