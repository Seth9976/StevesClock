// 函数: sub_402515
// 地址: 0x402515
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (sub_4061a0(arg1, 0x2a) == 0 && sub_4061a0(arg1, 0x3f) == 0)
    return sub_4016e0(arg1)

return sub_40169d(arg1)
