// 函数: sub_402d2f
// 地址: 0x402d2f
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

void* result = data_41fdbc

if (result != 0)
    int32_t esi_1 = 0
    
    if (result - 1 s>= 0)
        while (true)
            sub_401e81()
            sub_401df0()
            sub_402bcf(*(data_41fdc0 + (esi_1 << 2)))
            sub_401e30()
            data_421f3c = 1
            
            if (data_41fdb0 == 0)
                do
                    if (sub_401046(sub_4013ca(sub_401eb3()), "playing") != 0)
                        break
                    
                    sub_4016f5()
                while (data_41fdb0 == 0)
                
                if (data_41fdb0 == 0)
                    esi_1 += 1
                    
                    if (esi_1 s> data_41fdbc - 1)
                        break
                    
                    continue
            
            sub_401e81()
            sub_401df0()
            data_421f3c = 0
            data_41fdb0 = 0
            break
    
    sub_401e81()
    result = sub_401df0()
    data_421f3c = 0

return result
