// 函数: sub_4034f9
// 地址: 0x4034f9
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

data_426acc = 0xffffffff
char const* const var_14 = "\13.wav"
int32_t var_18 = arg1

if (sub_402515(sub_40158a(2)) != 0)
    char const* const var_14_1 = "\21.wav"
    int32_t var_18_1 = arg1
    int32_t eax_3 = sub_402515(sub_40158a(2))
    
    if (eax_3 == 0)
        data_426acc &= eax_3

char const* const var_14_2 = "\ty.wav"
int32_t var_18_2 = arg1

if (sub_402515(sub_40158a(2)) != 0)
    char const* const var_14_3 = "\1a.wav"
    int32_t var_18_3 = arg1
    
    if (sub_402515(sub_40158a(2)) == 0)
        data_426acc = 1

char const* const var_14_4 = "\9.wav"
int32_t var_18_4 = arg1

if (sub_402515(sub_40158a(2)) != 0)
    char const* const var_14_5 = "\10.wav"
    int32_t var_18_5 = arg1
    
    if (sub_402515(sub_40158a(2)) == 0)
        data_426acc = 2

char const* const var_14_6 = "\13.wav"
int32_t var_18_6 = arg1

if (sub_402515(sub_40158a(2)) != 0)
    char const* const var_14_7 = "\21.wav"
    int32_t var_18_7 = arg1
    
    if (sub_402515(sub_40158a(2)) != 0)
        data_426acc = 3

char const* const var_14_8 = "\15.wav"
int32_t var_18_8 = arg1

if (sub_402515(sub_40158a(2)) != 0)
    char const* const var_14_9 = "\1.wav"
    int32_t var_18_9 = arg1
    
    if (sub_402515(sub_40158a(2)) == 0)
        data_426acc = 4

char const* const var_14_10 = "\ty.wav"
int32_t var_18_10 = arg1

if (sub_402515(sub_40158a(2)) != 0)
    char const* const var_14_11 = "\1a.wav"
    int32_t var_18_11 = arg1
    
    if (sub_402515(sub_40158a(2)) != 0)
        data_426acc = 5

char const* const var_14_12 = "\cuckoo.wav"
int32_t var_18_12 = arg1

if (sub_402515(sub_40158a(2)) != 0)
    data_426acc = 6

char const* const var_14_13 = "\hour01.wav"
int32_t var_18_13 = arg1

if (sub_402515(sub_40158a(2)) != 0)
    data_426acc = 7

char const* const var_14_14 = "\ty1a.wav"
int32_t var_18_14 = arg1

if (sub_402515(sub_40158a(2)) != 0)
    data_426acc = 8

char const* const var_14_15 = "\and.wav"
int32_t var_18_15 = arg1

if (sub_402515(sub_40158a(2)) != 0)
    data_426acc = 9

return data_426acc
