// 函数: sub_403d8f
// 地址: 0x403d8f
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t var_4 = 0x800
int32_t var_8 = 0
int32_t* result = __snwscanf_l(data_41fdc0, 1, 0, 2)
data_41fdbc = 0
data_41fdc0 = result
return result
