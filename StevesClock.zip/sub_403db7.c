// 函数: sub_403db7
// 地址: 0x403db7
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

char* result = sub_402515(arg1)

if (result == 0)
    return result

if (data_421f3c != 0)
    data_41fdb0 = 1
    return result

data_41fdbc += 1
int32_t var_4 = 0x800
int32_t var_8_1 = data_41fdbc
int32_t* eax = __snwscanf_l(data_41fdc0, 1, 1, 2)
char* var_20_1 = eax[data_41fdbc - 1]
data_41fdc0 = eax
return _strcpy(var_20_1, arg1)
