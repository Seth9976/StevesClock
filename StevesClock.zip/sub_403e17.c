// 函数: sub_403e17
// 地址: 0x403e17
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t* eax = data_41fdc0
data_41fdbc = 0

if (eax != 0)
    sub_40172e(eax, 2, 1)
    eax = nullptr
    data_41fdc0 = 0

int32_t var_4 = 0x800
int32_t var_8 = 0
int32_t* result = __snwscanf_l(eax, 1, 0, 2)
data_41fdc0 = result
return result
