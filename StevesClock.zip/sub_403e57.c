// 函数: sub_403e57
// 地址: 0x403e57
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (data_421f3c != 0)
    data_41fdb0 = 1

return sub_403e17() __tailcall
