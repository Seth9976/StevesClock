// 函数: sub_403e6f
// 地址: 0x403e6f
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

_strcpy(0x427388, sub_4013ca(arg1))
char const* const var_1c = ".wav"
int32_t var_20 = 0x427388
int32_t var_24 = 0x41ff08
char* result = sub_402515(sub_4013ca(sub_40158a(3)))
data_427380 = result

if (result == 0)
    return result

char const* const var_10_1 = ".wav"
int32_t var_14_1 = 0x427388
int32_t var_18_1 = 0x41ff08
return sub_403db7(sub_40158a(3))
