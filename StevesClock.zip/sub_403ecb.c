// 函数: sub_403ecb
// 地址: 0x403ecb
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t eax
long double st0
st0, eax = __ismbcupper(arg1)
long double temp2 = fconvert.t(13.0)
st0 - temp2
eax.w = (st0 < temp2 ? 1 : 0) << 8 | (is_unordered.t(st0, temp2) ? 1 : 0) << 0xa
    | (st0 == temp2 ? 1 : 0) << 0xe
bool p = unimplemented  {test ah, 0x5}

if (not(p))
    char const* const __saved_edi_1 = ".wav"
    char* var_c = arg1
    int32_t var_10_1 = 0x41ff08
    return sub_403db7(sub_40158a(3))

int32_t eax_3
long double st0_1
st0_1, eax_3 = __ismbcupper(arg1)
long double temp3 = fconvert.t(20.0)
st0_1 - temp3
eax_3.w = (st0_1 < temp3 ? 1 : 0) << 8 | (is_unordered.t(st0_1, temp3) ? 1 : 0) << 0xa
    | (st0_1 == temp3 ? 1 : 0) << 0xe
bool p_1 = unimplemented  {test ah, 0x5}

if (p_1)
    char* result
    long double st0_3
    st0_3, result = __ismbcupper(arg1)
    long double temp4_1 = fconvert.t(19.0)
    st0_3 - temp4_1
    result.w = (st0_3 < temp4_1 ? 1 : 0) << 8 | (is_unordered.t(st0_3, temp4_1) ? 1 : 0) << 0xa
        | (st0_3 == temp4_1 ? 1 : 0) << 0xe
    
    if ((result:1.b & 0x41) != 0)
        return result
    
    _strcpy(0x427b90, arg1)
    data_427b8c = sub_407fc0(__ismbcupper(sub_4010b3(0x427b90, 1)))
    result = sub_407fc0(__ismbcupper(sub_4010ff(0x427b90, 1)))
    int32_t ecx_4 = data_427b8c
    data_427b88 = result
    
    if (ecx_4 != 2)
        if (ecx_4 == 3)
            char const* const var_c_13 = "thir.wav"
            goto label_404036
        
        if (ecx_4 == 4)
            char const* const var_c_14 = "for.wav"
            goto label_404036
        
        if (ecx_4 == 5)
            char const* const var_c_15 = "fif.wav"
            goto label_404036
    else
        char const* const var_c_12 = "twen.wav"
    label_404036:
        int32_t var_10_3 = 0x41ff08
        sub_403db7(sub_40158a(2))
        result = data_427b88
    
    if (result == 0)
        char const* const var_c_16 = "ty.wav"
    else if (result == 1)
        char const* const var_c_17 = "ty1.wav"
    else if (result == 2)
        char const* const var_c_18 = "ty2.wav"
    else if (result == 3)
        char const* const var_c_19 = "ty3.wav"
    else if (result == 4)
        char const* const var_c_20 = "ty4.wav"
    else if (result == 5)
        char const* const var_c_21 = "ty5.wav"
    else if (result == 6)
        char const* const var_c_22 = "ty6.wav"
    else if (result == 7)
        char const* const var_c_23 = "ty7.wav"
    else if (result != 8)
        if (result != 9)
            return result
        
        char const* const var_c_25 = "ty9.wav"
    else
        char const* const var_c_24 = "ty8.wav"
else
    int32_t eax_4 = sub_407fc0(__ismbcupper(arg1))
    data_428390 = eax_4
    int32_t var_10_2
    
    switch (mods.dp.d(sx.q(eax_4), 0xa))
        case 3
            char const* const var_c_3 = "thir.wav"
            var_10_2 = 0x41ff08
            sub_403db7(sub_40158a(2))
        case 4
            char const* const var_c_4 = "for.wav"
            var_10_2 = 0x41ff08
            sub_403db7(sub_40158a(2))
        case 5
            char const* const var_c_5 = "fif.wav"
            var_10_2 = 0x41ff08
            sub_403db7(sub_40158a(2))
        case 6
            char const* const var_c_6 = "six.wav"
            var_10_2 = 0x41ff08
            sub_403db7(sub_40158a(2))
        case 7
            char const* const var_c_7 = "seven.wav"
            var_10_2 = 0x41ff08
            sub_403db7(sub_40158a(2))
        case 8
            char const* const var_c_8 = "eight.wav"
            var_10_2 = 0x41ff08
            sub_403db7(sub_40158a(2))
        case 9
            char const* const var_c_9 = "nine.wav"
            var_10_2 = 0x41ff08
            sub_403db7(sub_40158a(2))
    
    char const* const var_c_10 = "teen.wav"

int32_t var_10_4 = 0x41ff08
return sub_403db7(sub_40158a(2))
