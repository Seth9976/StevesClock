// 函数: sub_4040d2
// 地址: 0x4040d2
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

void* i = _strlen(arg1)
data_428398 = i
data_428394 = 1

if (i s>= 1)
    do
        char const* const var_4 = ".wav"
        int128_t* var_8_1 = sub_401133(arg1, data_428394, 1)
        int32_t var_c_2 = 0x41ff08
        sub_403db7(sub_40158a(3))
        data_428394 += 1
        i = data_428394
    while (i s<= data_428398)

return i
