// 函数: sub_404133
// 地址: 0x404133
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

char const* const var_4 = ".wav"
int32_t var_8 = arg1
int32_t var_c = 0x41ff08
return sub_403db7(sub_40158a(3))
