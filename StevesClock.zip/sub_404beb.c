// 函数: sub_404beb
// 地址: 0x404beb
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

LRESULT eax = sub_40240f(data_41bae8)
HWND var_8 = data_41bae8
data_42b3f8 = eax
LRESULT result = sub_402423(var_8)
data_42b3f4 = result

if (result s<= 0)
    data_42b3f4 = 0
    return result

sub_40249e(data_41bae8, result - 1)
sub_403e57()
char const* const var_4_1 = "\beep.wav"
uint8_t* var_8_2 = sub_401422()
sub_403db7(sub_40158a(2))
return sub_402d2f() __tailcall
