// 函数: sub_405db6
// 地址: 0x405db6
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

LRESULT result = sub_402423(data_41bae8)
data_42dc88 = result

if (result == 0)
    return result

sub_403e57()
_strcpy(0x41b2e0, *(data_41bae4 + (data_42dc88 << 2)))
sub_4056c0(0x41b2e0, data_42dc88)
return sub_402d2f() __tailcall
