// 函数: sub_405e00
// 地址: 0x405e00
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

sub_401f26()
uint32_t result = sub_405c89()

if (result == 0)
    result = sub_402306()
    
    if (result == 0)
        sub_405a5a()
        sub_405ae3()
        sub_405b6c()
        return sub_405bf5() __tailcall

return result
