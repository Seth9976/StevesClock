// 函数: sub_405e2c
// 地址: 0x405e2c
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

switch (arg1)
    case 0
        sub_405db6()
    case 1
        bool eax = data_420f08 == 0
        data_42dc8c = eax
        CheckDlgButton(data_41eb90, 0x69, zx.d(eax))
        sub_402de0()
    case 2
        sub_404beb()
    case 3
        sub_404c4d()
    case 4
        sub_401fd1()
    case 5
        SendMessageA(data_41eb90, 0x10, 0, 0)
