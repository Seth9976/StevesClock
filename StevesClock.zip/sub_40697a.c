// 函数: sub_40697a
// 地址: 0x40697a
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return __unlock_file(*(arg1 + 0xc))
