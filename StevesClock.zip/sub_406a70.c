// 函数: sub_406a70
// 地址: 0x406a70
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return __unlock_file(arg1)
