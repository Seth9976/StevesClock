// 函数: sub_40712b
// 地址: 0x40712b
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

void* var_14
sub_4070a4(&var_14, arg2)
void* eax = var_14
int32_t result

if (*(eax + 0xac) s<= 1)
    result = zx.d(*(*(eax + 0xc8) + (arg1 << 1))) & 4
else
    result = sub_40b115(arg1, 4, &var_14)

char var_8
void* var_c

if (var_8 != 0)
    *(var_c + 0x70) &= 0xfffffffd
return result
