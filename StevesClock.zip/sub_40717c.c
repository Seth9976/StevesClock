// 函数: sub_40717c
// 地址: 0x40717c
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (data_42ddc8 != 0)
    return sub_40712b(arg1, nullptr)

return zx.d((*data_41acb8)[arg1]) & 4
