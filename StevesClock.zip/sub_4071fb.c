// 函数: sub_4071fb
// 地址: 0x4071fb
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (data_42ddc8 != 0)
    return sub_4071aa(arg1, nullptr)

return zx.d((*data_41acb8)[arg1]) & 8
