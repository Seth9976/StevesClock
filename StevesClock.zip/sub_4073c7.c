// 函数: sub_4073c7
// 地址: 0x4073c7
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

void var_14
sub_4070a4(&var_14, arg3)
int32_t result = sub_407249(arg1, arg2, &var_14)
char var_8
void* var_c

if (var_8 != 0)
    *(var_c + 0x70) &= 0xfffffffd
return result
