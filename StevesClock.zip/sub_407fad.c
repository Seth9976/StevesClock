// 函数: sub_407fad
// 地址: 0x407fad
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t eax
int32_t edx
int32_t ebp
int32_t esi
int32_t edi

if (arg1 != __security_cookie)
    noreturn sub_40d111(eax, edx, arg1, ebp, esi, edi) __tailcall
