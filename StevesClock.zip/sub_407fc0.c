// 函数: sub_407fc0
// 地址: 0x407fc0
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (data_42e9d8 == 0)
    return __ftol2(arg1) __tailcall

return int.d(fconvert.t(fconvert.d(arg1)))
