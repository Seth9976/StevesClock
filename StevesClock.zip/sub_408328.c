// 函数: sub_408328
// 地址: 0x408328
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return sub_408542(arg1, *(data_42eb1c + (arg1 << 2)))
