// 函数: sub_4083a9
// 地址: 0x4083a9
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return __unlock_file(*(arg1 + 8))
