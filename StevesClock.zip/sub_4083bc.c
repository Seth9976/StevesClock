// 函数: sub_4083bc
// 地址: 0x4083bc
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return &data_41a010
