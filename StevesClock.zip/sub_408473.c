// 函数: sub_408473
// 地址: 0x408473
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

sub_4083b3()

if (data_42dcc0 != 0)
    sub_40e428()

return __free_base(data_42eb1c)
