// 函数: sub_4084d4
// 地址: 0x4084d4
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (arg1 s>= 0x14)
    return EnterCriticalSection(arg2 + 0x20)

sub_40e3f5(arg1 + 0x10)
*(arg2 + 0xc) |= 0x8000
return arg2
