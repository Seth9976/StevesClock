// 函数: sub_40864a
// 地址: 0x40864a
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return __unlock_file(arg1)
