// 函数: sub_408782
// 地址: 0x408782
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return __unlock_file(arg1)
