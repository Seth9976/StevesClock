// 函数: sub_4087cd
// 地址: 0x4087cd
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return sub_40e3f5(8)
