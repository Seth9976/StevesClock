// 函数: sub_4087d6
// 地址: 0x4087d6
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return __unlock(8)
