// 函数: sub_4087df
// 地址: 0x4087df
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t eax = sub_40aca1()
__initp_misc_purevirt(eax)
__initp_misc_invarg(eax)
___set_app_type(eax)
__set_pgmptr(eax)
___acrt_initialize_signal_handlers(eax)
int32_t var_1c = eax
return __initp_eh_hooks()
