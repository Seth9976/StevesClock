// 函数: sub_408836
// 地址: 0x408836
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (sub_40eae0(&data_4168b4) != 0)
    __fpmath(arg1)

sub_40ce0a()
int32_t result = __initterm_e(0x416244, 0x41625c)

if (result != 0)
    return result

int32_t edi
int32_t var_c_1 = edi
_atexit(sub_40ea22)

for (void* const i = &data_41623c; i u< 0x416240; i += 4)
    int32_t eax_2 = *i
    
    if (eax_2 != 0)
        eax_2()

if (data_42eb18 != 0 && sub_40eae0(&data_42eb18) != 0)
    data_42eb18(0, 2, 0)

return 0
