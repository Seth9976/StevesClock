// 函数: sub_408c3d
// 地址: 0x408c3d
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return sub_408b81(arg1, arg2, 0x40)
