// 函数: sub_408dac
// 地址: 0x408dac
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t* eax_1 = *(arg1 - 0x14)
int32_t ecx_1 = **eax_1
*(arg1 - 0x24) = ecx_1
return sub_40f3f2(ecx_1, eax_1)
