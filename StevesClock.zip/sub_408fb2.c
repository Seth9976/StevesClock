// 函数: sub_408fb2
// 地址: 0x408fb2
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

sub_408e89(2, 0xc0000417, 1)
TerminateProcess(GetCurrentProcess(), 0xc0000417)
noreturn
