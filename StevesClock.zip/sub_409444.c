// 函数: sub_409444
// 地址: 0x409444
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return __unlock(7)
