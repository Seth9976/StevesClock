// 函数: sub_4098e8
// 地址: 0x4098e8
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return __unlock(6)
