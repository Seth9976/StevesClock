// 函数: sub_40995f
// 地址: 0x40995f
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (arg1 != 0)
    *arg1 = data_41a490
    return 0

*__errno() = 0x16
__invalid_parameter_noinfo()
return 0x16
