// 函数: sub_4099b9
// 地址: 0x4099b9
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return &data_41a48c
