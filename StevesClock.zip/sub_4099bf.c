// 函数: sub_4099bf
// 地址: 0x4099bf
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return &data_41a490
