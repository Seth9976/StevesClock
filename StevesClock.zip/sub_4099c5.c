// 函数: sub_4099c5
// 地址: 0x4099c5
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return &data_41a488
