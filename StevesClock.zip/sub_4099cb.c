// 函数: sub_4099cb
// 地址: 0x4099cb
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return &data_41a518
