// 函数: sub_40a274
// 地址: 0x40a274
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

data_42e9d8 = IsProcessorFeaturePresent(PF_XMMI64_INSTRUCTIONS_AVAILABLE)
return 0
