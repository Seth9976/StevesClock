// 函数: sub_40a284
// 地址: 0x40a284
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (arg1 == 0x3a4)
    return 0x411

if (arg1 == 0x3a8)
    return 0x804

if (arg1 == 0x3b5)
    return 0x412

if (arg1 == 0x3b6)
    return 0x404

return 0
