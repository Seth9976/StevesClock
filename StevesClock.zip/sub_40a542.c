// 函数: sub_40a542
// 地址: 0x40a542
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return __unlock(0xd)
