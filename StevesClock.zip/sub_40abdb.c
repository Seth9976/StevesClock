// 函数: sub_40abdb
// 地址: 0x40abdb
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t edi
int32_t var_8 = edi

if (arg2 == 0 || arg1 == 0)
    return nullptr

void* esi_1 = *arg1

if (esi_1 != arg2)
    *arg1 = arg2
    sub_40a968(arg2)
    
    if (esi_1 != 0)
        sub_40a9f7(esi_1)
        
        if (*esi_1 == 0 && esi_1 != 0x41abf0)
            sub_40aa90(esi_1)

return arg2
