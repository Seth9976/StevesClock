// 函数: sub_40ac95
// 地址: 0x40ac95
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t result = __unlock(0xc)
*(arg1 - 0x1c)
return result
