// 函数: sub_40aca1
// 地址: 0x40aca1
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return EncodePointer(nullptr)
