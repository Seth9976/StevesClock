// 函数: sub_40acaa
// 地址: 0x40acaa
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return TlsAlloc()
