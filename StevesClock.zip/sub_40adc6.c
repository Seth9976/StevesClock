// 函数: sub_40adc6
// 地址: 0x40adc6
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return __unlock(0xd)
