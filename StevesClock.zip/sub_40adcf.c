// 函数: sub_40adcf
// 地址: 0x40adcf
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return __unlock(0xc)
