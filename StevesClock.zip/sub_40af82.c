// 函数: sub_40af82
// 地址: 0x40af82
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

*(arg1 + 8)
return sub_40af85() __tailcall
