// 函数: sub_40af8e
// 地址: 0x40af8e
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

*(arg1 + 8)
return sub_40af91() __tailcall
