// 函数: sub_40af91
// 地址: 0x40af91
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return __unlock(0xc)
