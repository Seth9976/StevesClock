// 函数: sub_40b526
// 地址: 0x40b526
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

void arg_4
void* ecx_1 = (&arg_4 - arg1) & 7
return __chkstk((arg1 + ecx_1) | sbb.d(ecx_1, ecx_1, arg1 + ecx_1 u< arg1)) __tailcall
