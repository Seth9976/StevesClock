// 函数: sub_40b6a0
// 地址: 0x40b6a0
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if ((arg3[3].b & 0x40) == 0 || arg3[2] != 0)
    int32_t temp0_1 = arg3[1]
    arg3[1] -= 1
    
    if (temp0_1 - 1 s< 0)
        int32_t* var_4_1 = arg3
        arg1 = sub_40b53c(sx.d(arg1.b))
    else
        **arg3 = arg1.b
        *arg3 += 1
        arg1 = zx.d(arg1.b)
    
    if (arg1 == 0xffffffff)
        *arg4 |= arg1
        return 

*arg4 += 1
