// 函数: sub_40c44f
// 地址: 0x40c44f
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t var_c = arg3
int32_t arg_4
int32_t* result

if (arg_4 == 0)
    sub_411106(&arg_4, arg5, arg6)
    result = arg4
    *result = arg_4
else
    sub_41105e(&var_c, arg5, arg6)
    result = arg4
    *result = var_c
    result[1] = arg3

return result
