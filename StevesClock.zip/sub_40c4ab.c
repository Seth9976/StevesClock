// 函数: sub_40c4ab
// 地址: 0x40c4ab
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (arg2 != 0)
    sub_4111b0(arg1 + arg2, arg1, _strlen(arg1) + 1)
