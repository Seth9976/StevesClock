// 函数: sub_40ce2d
// 地址: 0x40ce2d
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t result = sub_411818(nullptr, 0x10000, 0x30000)

if (result == 0)
    return result

int32_t var_18
__builtin_memset(&var_18, 0, 0x14)
sub_408fb2()
noreturn
