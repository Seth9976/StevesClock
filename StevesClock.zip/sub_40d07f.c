// 函数: sub_40d07f
// 地址: 0x40d07f
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (data_42ddc8 != 0)
    return sub_40cfbf(arg1, arg2, nullptr)

if (arg1 != 0 && arg2 != 0)
    return sub_40cf86(arg1, arg2) __tailcall

*__errno() = 0x16
__invalid_parameter_noinfo()
return 0x7fffffff
