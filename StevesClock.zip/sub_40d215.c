// 函数: sub_40d215
// 地址: 0x40d215
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

*arg1
