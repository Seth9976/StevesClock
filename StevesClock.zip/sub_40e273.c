// 函数: sub_40e273
// 地址: 0x40e273
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t entry_ebx
return sub_4128ec(entry_ebx)
