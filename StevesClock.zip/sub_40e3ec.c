// 函数: sub_40e3ec
// 地址: 0x40e3ec
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return __unlock(0xa)
