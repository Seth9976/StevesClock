// 函数: sub_40e3f5
// 地址: 0x40e3f5
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (*((arg1 << 3) + &data_41ad10) == 0 && sub_40e333(arg1) == 0)
    __amsg_exit(0x11)
    noreturn

return EnterCriticalSection(*((arg1 << 3) + &data_41ad10))
