// 函数: sub_40e61c
// 地址: 0x40e61c
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t entry_ebx
return sub_4128ec(entry_ebx)
