// 函数: sub_40e679
// 地址: 0x40e679
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

*(arg1 - 4) = 0xfffffffe
sub_412aac()
noreturn
