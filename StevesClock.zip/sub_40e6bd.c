// 函数: sub_40e6bd
// 地址: 0x40e6bd
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

void* result = arg3

while (*(result + 4) != arg2)
    result += 0xc
    
    if (result u>= 0x90 + arg3)
        break

if (result u< 0x90 + arg3 && *(result + 4) == arg2)
    return result

return nullptr
