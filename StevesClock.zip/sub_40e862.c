// 函数: sub_40e862
// 地址: 0x40e862
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

*(arg1 + 8)
*(arg1 - 0x28)
return sub_40e868(arg1) __tailcall
