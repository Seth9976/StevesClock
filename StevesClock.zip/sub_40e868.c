// 函数: sub_40e868
// 地址: 0x40e868
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (*(arg1 - 0x1c) != 0)
    __unlock(0)
