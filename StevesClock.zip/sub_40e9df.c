// 函数: sub_40e9df
// 地址: 0x40e9df
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return sub_4087d6()
