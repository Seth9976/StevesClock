// 函数: sub_40e9fc
// 地址: 0x40e9fc
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t edi
int32_t var_8 = edi
return &data_4181e0
