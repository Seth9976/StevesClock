// 函数: sub_40ea22
// 地址: 0x40ea22
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t edi
int32_t var_8 = edi
return &data_4181e8
