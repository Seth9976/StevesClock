// 函数: sub_40ea50
// 地址: 0x40ea50
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (*arg1 == 0x5a4d)
    void* eax_3 = *(arg1 + 0x3c) + arg1
    
    if (*eax_3 == 0x4550)
        int32_t result
        result.b = *(eax_3 + 0x18) == 0x10b
        return result

return 0
