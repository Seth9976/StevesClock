// 函数: sub_40eb6b
// 地址: 0x40eb6b
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t result
result.b = ***(arg1 - 0x14) == 0xc0000005
return result
