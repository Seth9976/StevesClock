// 函数: sub_40eb9c
// 地址: 0x40eb9c
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

for (int32_t i = 0; i u< 0x16; i += 1)
    if (arg1 == *((i << 3) + &data_417648))
        return (&data_41764c)[i * 2]

return 0
