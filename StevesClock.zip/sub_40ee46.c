// 函数: sub_40ee46
// 地址: 0x40ee46
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (arg1 == 0 || (arg2[3] & 0x1000) == 0)
    return 

sub_4081d6(arg2)
arg2[3] &= 0xffffeeff
arg2[6] = 0
*arg2 = 0
arg2[2] = 0
