// 函数: sub_40f372
// 地址: 0x40f372
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return RtlUnwind(arg1, 0x40f386, arg2, nullptr)
