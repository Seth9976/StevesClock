// 函数: sub_40f3a2
// 地址: 0x40f3a2
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t* eax_1 = *arg1

if (*eax_1 == 0xe06d7363 && eax_1[4] == 3)
    int32_t eax_2 = eax_1[5]
    
    if (eax_2 == 0x19930520 || eax_2 == 0x19930521 || eax_2 == 0x19930522 || eax_2 == 0x1994000)
        terminate()
        noreturn

return 0
