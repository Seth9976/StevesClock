// 函数: sub_40f3e4
// 地址: 0x40f3e4
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

SetUnhandledExceptionFilter(sub_40f3a2)
return 0
