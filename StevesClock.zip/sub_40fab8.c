// 函数: sub_40fab8
// 地址: 0x40fab8
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

data_42e9d4 = 0
