// 函数: sub_40fac0
// 地址: 0x40fac0
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return sub_413ded(arg1, nullptr, 0xa)
