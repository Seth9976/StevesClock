// 函数: sub_40fc9f
// 地址: 0x40fc9f
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

uint32_t* eax_2 = __getptd()
void* eax = eax_2[0x1b]

if (eax != data_41acc8 && (eax_2[0x1c] & data_41aa80) == 0)
    eax = sub_40ac28()

return *(eax + 4)
