// 函数: sub_410c60
// 地址: 0x410c60
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return sub_4128ec(*(arg1 + 8))
