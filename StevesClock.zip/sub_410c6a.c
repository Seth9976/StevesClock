// 函数: sub_410c6a
// 地址: 0x410c6a
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (arg1 != 0xfffffffe)
    if (arg1 s>= 0 && arg1 u< data_42e9e0)
        return sx.d(*((&data_42ea00)[arg1 s>> 5] + ((arg1 & 0x1f) << 6) + 4)) & 0x40
    
    *__errno() = 9
    __invalid_parameter_noinfo()
else
    *__errno() = 9

return 0
