// 函数: sub_410cc0
// 地址: 0x410cc0
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t result
result.b = data_42e9b0 == (__security_cookie | 1)
return result
