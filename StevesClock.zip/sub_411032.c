// 函数: sub_411032
// 地址: 0x411032
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

uint32_t result

if (data_42ddc8 != 0)
    result = sub_410f1d(arg1, nullptr)
else
    result = arg1
    
    if (result - 0x41 u<= 0x19)
        return result + 0x20

return result
