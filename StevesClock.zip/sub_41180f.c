// 函数: sub_41180f
// 地址: 0x41180f
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

__amsg_exit(2)
noreturn
