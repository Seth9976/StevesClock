// 函数: sub_4128e3
// 地址: 0x4128e3
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return __unlock(0xa)
