// 函数: sub_4128ec
// 地址: 0x4128ec
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return LeaveCriticalSection((&data_42ea00)[arg1 s>> 5] + ((arg1 & 0x1f) << 6) + 0xc)
