// 函数: sub_4129e5
// 地址: 0x4129e5
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return __unlock(0xa)
