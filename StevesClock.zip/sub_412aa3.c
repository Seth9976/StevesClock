// 函数: sub_412aa3
// 地址: 0x412aa3
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

return __unlock(0xb)
