// 函数: sub_412aac
// 地址: 0x412aac
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (sub_40e6f4() != 0)
    sub_40e701(0x16)

if ((data_41b28c & 2) != 0)
    sub_408e89(3, 0x40000015, 1)

_quick_exit(3)
noreturn
