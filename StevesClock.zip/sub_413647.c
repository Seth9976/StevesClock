// 函数: sub_413647
// 地址: 0x413647
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (*(arg1 - 0x1c) == arg3)
    return 

if (*(arg1 - 0x20) != arg3)
    int32_t eax_1 = *arg2
    char* eax_4 = (&data_42ea00)[eax_1 s>> 5] + ((eax_1 & 0x1f) << 6) + 4
    *eax_4 &= 0xfe

sub_4128ec(*arg2)
