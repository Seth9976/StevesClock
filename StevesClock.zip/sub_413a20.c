// 函数: sub_413a20
// 地址: 0x413a20
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t ebp
int32_t var_4 = ebp
int32_t result = RtlUnwind(arg1, 0x413a38, nullptr, nullptr)
var_4
return result
