// 函数: sub_413ded
// 地址: 0x413ded
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

void** var_18

if (data_42ddc8 != 0)
    var_18 = nullptr
else
    var_18 = &data_41accc

return sub_413bc2(var_18, arg1, arg2, arg3, 0)
