// 函数: sub_414089
// 地址: 0x414089
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (data_42ddc8 != 0)
    return sub_413fa7(arg1, arg2, arg3, nullptr)

if (arg1 != 0 && arg2 != 0 && arg3 u<= 0x7fffffff)
    return ___ascii_strnicmp(arg1, arg2, arg3) __tailcall

*__errno() = 0x16
__invalid_parameter_noinfo()
return 0x7fffffff
