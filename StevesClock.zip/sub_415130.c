// 函数: sub_415130
// 地址: 0x415130
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

if (arg1 != 0)
    *arg1 = data_42e9d0
    return 0

*__errno() = 0x16
__invalid_parameter_noinfo()
return 0x16
