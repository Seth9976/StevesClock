// 函数: sub_4153cb
// 地址: 0x4153cb
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

void var_14
enum COMPARESTRING_RESULT result =
    sub_41515d(sub_4070a4(&var_14, arg1), arg6, &var_14, arg2, arg3, arg4, arg5, arg7, arg8)
char var_8
void* var_c

if (var_8 != 0)
    *(var_c + 0x70) &= 0xfffffffd
return result
