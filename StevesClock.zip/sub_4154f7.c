// 函数: sub_4154f7
// 地址: 0x4154f7
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t* esi = data_42dca8

while (true)
    char* eax_3 = *esi
    
    if (eax_3 == 0)
        break
    
    if (__mbsnbset(arg2, eax_3, arg1) == 0)
        int32_t eax_2
        eax_2.b = arg1[*esi]
        
        if (eax_2.b == 0x3d || eax_2.b == 0)
            return (esi - data_42dca8) s>> 2
    
    esi = &esi[1]

return neg.d((esi - data_42dca8) s>> 2)
