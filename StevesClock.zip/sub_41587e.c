// 函数: sub_41587e
// 地址: 0x41587e
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t eax_1 = ***(arg1 - 0x14)

if (eax_1 != 0xc0000005 && eax_1 != 0xc000001d)
    return 0

return 1
