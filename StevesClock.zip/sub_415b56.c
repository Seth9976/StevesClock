// 函数: sub_415b56
// 地址: 0x415b56
// 来自: E:/torrent/Tools/StevesClock/StevesClock.exe.bndb

int32_t edi
int32_t var_1c = edi
void var_14
sub_4070a4(&var_14, arg3)
int32_t result = sub_4159e2(arg1, arg2)
char var_8
void* var_c

if (var_8 != 0)
    *(var_c + 0x70) &= 0xfffffffd
return result
